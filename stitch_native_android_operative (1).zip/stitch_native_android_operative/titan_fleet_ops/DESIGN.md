---
name: Titan Fleet Ops
colors:
  surface: '#141313'
  surface-dim: '#141313'
  surface-bright: '#3a3939'
  surface-container-lowest: '#0e0e0e'
  surface-container-low: '#1c1b1b'
  surface-container: '#201f1f'
  surface-container-high: '#2b2a2a'
  surface-container-highest: '#353434'
  on-surface: '#e5e2e1'
  on-surface-variant: '#c4c7c7'
  inverse-surface: '#e5e2e1'
  inverse-on-surface: '#313030'
  outline: '#8e9192'
  outline-variant: '#444748'
  surface-tint: '#c8c6c5'
  primary: '#c8c6c5'
  on-primary: '#303030'
  primary-container: '#212121'
  on-primary-container: '#898888'
  inverse-primary: '#5f5e5e'
  secondary: '#b8c9d3'
  on-secondary: '#23333a'
  secondary-container: '#3b4b53'
  on-secondary-container: '#aabbc5'
  tertiary: '#c9c6c4'
  on-tertiary: '#31302f'
  tertiary-container: '#222120'
  on-tertiary-container: '#8b8886'
  error: '#ffb4ab'
  on-error: '#690005'
  error-container: '#93000a'
  on-error-container: '#ffdad6'
  primary-fixed: '#e5e2e1'
  primary-fixed-dim: '#c8c6c5'
  on-primary-fixed: '#1b1c1c'
  on-primary-fixed-variant: '#474746'
  secondary-fixed: '#d4e5ef'
  secondary-fixed-dim: '#b8c9d3'
  on-secondary-fixed: '#0d1e25'
  on-secondary-fixed-variant: '#394951'
  tertiary-fixed: '#e6e2e0'
  tertiary-fixed-dim: '#c9c6c4'
  on-tertiary-fixed: '#1c1b1a'
  on-tertiary-fixed-variant: '#484645'
  background: '#141313'
  on-background: '#e5e2e1'
  surface-variant: '#353434'
  operative-green: '#2E7D32'
  warning-orange: '#ED6C02'
  critical-red: '#D32F2F'
  data-blue: '#0288D1'
  surface-border: '#424242'
  text-dim: '#9E9E9E'
typography:
  headline-lg:
    fontFamily: IBM Plex Sans
    fontSize: 24px
    fontWeight: '700'
    lineHeight: 32px
    letterSpacing: -0.02em
  headline-md:
    fontFamily: IBM Plex Sans
    fontSize: 20px
    fontWeight: '600'
    lineHeight: 28px
  body-lg:
    fontFamily: IBM Plex Sans
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 24px
  body-sm:
    fontFamily: IBM Plex Sans
    fontSize: 14px
    fontWeight: '400'
    lineHeight: 20px
  label-caps:
    fontFamily: JetBrains Mono
    fontSize: 12px
    fontWeight: '700'
    lineHeight: 16px
    letterSpacing: 0.08em
  data-mono:
    fontFamily: JetBrains Mono
    fontSize: 13px
    fontWeight: '500'
    lineHeight: 18px
  headline-lg-mobile:
    fontFamily: IBM Plex Sans
    fontSize: 20px
    fontWeight: '700'
    lineHeight: 28px
rounded:
  sm: 0.125rem
  DEFAULT: 0.25rem
  md: 0.375rem
  lg: 0.5rem
  xl: 0.75rem
  full: 9999px
spacing:
  unit: 4px
  gutter: 8px
  margin-mobile: 12px
  margin-desktop: 24px
  stack-sm: 4px
  stack-md: 12px
  stack-lg: 20px
---

## Brand & Style

The design system is engineered for high-stakes operational environments where speed of data comprehension and reliability are paramount. It targets fleet managers and security professionals who require an "experimental and operative" interface—one that feels like a precision instrument rather than a consumer app.

The aesthetic follows a **High-Contrast / Bold** movement with a heavy emphasis on **Modern / Technical** utility. It utilizes a deep dark mode to reduce eye strain during night operations and to make semantic status colors pop with absolute clarity. The interface is data-dense, minimizing whitespace in favor of information "glanceability," and employs a rigid structural grid to convey a sense of stability and engineered order.

## Colors

The palette is strictly functional. The background is a deep near-black to provide maximum contrast for semantic indicators. 

- **Primary & Secondary:** These are neutrals used for surfaces, containers, and chrome to ensure they do not compete with status data.
- **Semantic Tokens:** 
    - `operative-green` indicates active agents, healthy telemetry, and successful commands.
    - `warning-orange` highlights maintenance requirements or degraded signal strength.
    - `critical-red` is reserved for offline assets, security breaches, or system errors.
- **Named Colors:** `data-blue` is used for interactive elements (CTAs) and primary statistics that are informational but not status-critical.

## Typography

This design system utilizes a dual-font strategy to balance readability with a technical aesthetic. **IBM Plex Sans** is used for the majority of the UI to provide a professional, systematic feel. **JetBrains Mono** is employed for technical metadata, timestamps, coordinates, and command logs to reinforce the "operative" nature of the tool.

- **Headlines:** Use Bold weights with slight negative letter spacing for a compact, authoritative look.
- **Data Labels:** Always in `label-caps` (Uppercase JetBrains Mono) to distinguish category headers from live data.
- **Technical Readouts:** Use `data-mono` for all variable values (e.g., IP addresses, coordinates) to ensure character alignment and rapid scanning.

## Layout & Spacing

The layout utilizes a **Fixed Grid** model based on a 4px baseline shift. In this operative context, density is prioritized over "breathability."

- **Grid System:** A 12-column grid for desktop/tablet and a 4-column grid for mobile.
- **Margins:** Tight margins (12px on mobile) are used to maximize the screen real estate for data tables and telemetry maps.
- **Reflow Rules:** 
    - **Stats Cards:** 3-up on mobile, 6-up on desktop.
    - **Telemetry Grids:** 2-up on mobile, 4-up on desktop.
- **Component Spacing:** Use `stack-sm` for internal card padding between related elements (e.g., icon and label) and `stack-md` for spacing between distinct data groups.

## Elevation & Depth

To maintain a "tactical dashboard" feel, the system avoids soft shadows and organic depth. Hierarchy is established through **Tonal Layers** and **Bold Borders**.

- **Surface Tiers:** 
    - Level 0: Pure black (`#000000`) background.
    - Level 1: Primary surface (`#212121`) for cards and list items.
    - Level 2: Secondary surface (`#37474F`) for nested elements or active states.
- **Borders:** All containers use a 1px solid border (`surface-border`). Status-critical cards may adopt a colored border (e.g., 2px `critical-red`) to demand immediate attention.
- **Active State:** Instead of elevation, active or "pressed" states are indicated by a high-contrast color fill or an inner-glow effect.

## Shapes

The shape language is **Soft (0.25rem)**. This slight rounding provides just enough distinction between UI components and the physical screen edge while maintaining a rigid, industrial silhouette. 

- **Standard Elements:** Buttons, input fields, and small cards use the base 4px radius.
- **Status Indicators:** Status dots (🟢) and markers remain perfectly circular to act as distinct "pills" of color within the rectangular grid.
- **Command Logs:** Log entries are strictly rectangular (0px radius) to emphasize their nature as lines of raw data.

## Components

### Status Cards
Cards are the primary data containers. They must feature a fixed-height header with a `label-caps` category and a status indicator (dot or icon) in the top-right corner. Telemetry values within cards should use `data-mono`.

### Telemetry Grids
A high-density grid for displaying live sensor data (Battery, RSSI, GPS). Each cell consists of a small icon, a value (`data-mono`), and a unit label. Cells change background color slightly on update to indicate a "heartbeat" of live data.

### Command-Log Lists
A monospaced list component for technical logs. Each row includes a timestamp, an event type, and a message. Use `critical-red` or `operative-green` for the text color of the event type to allow rapid scrolling for errors.

### Buttons
- **Primary:** Solid `data-blue` with white `label-caps` text.
- **Operative:** Solid `operative-green` for "Start," "Unlock," or "Enable" actions.
- **Destructive:** Outlined `critical-red` for "Stop," "Lock," or "Delete."
- All buttons use a 1px border and 4px radius.

### Input Fields
Dark-filled fields with `surface-border` and `text-dim` placeholders. On focus, the border changes to `data-blue`. Use `data-mono` for the input text to ensure clarity for technical strings like IP addresses or device IDs.

### Chips
Used for filtering asset lists (e.g., "Online," "Offline," "Maintenance"). Chips should be low-profile, using an outline style that switches to a solid semantic fill when selected.